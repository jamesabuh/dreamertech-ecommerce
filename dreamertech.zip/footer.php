<div class="bg-info p-3 text-center">
    <p>All rights reserved @- Designed by Khanam-2022</p>
</div>